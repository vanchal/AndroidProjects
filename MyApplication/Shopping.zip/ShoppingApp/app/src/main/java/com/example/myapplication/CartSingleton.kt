package com.example.myapplication

object CartSingleton {
    var cartList = arrayListOf<CartItem>()

    fun addItem(product: Shopping) {
        cartList.add(CartItem(product, 1))
    }

    fun removeItem(product: Shopping) {
        cartList.remove(CartItem(product, 1))
    }

    fun modifyQuantity(product: Shopping, newQuantity : Int) {

    }
}
data class CartItem(var product : Shopping, var quantity : Int) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as CartItem

        if (product.id != other.product.id) return false

        return true
    }

    override fun hashCode(): Int {
        return product.hashCode()
    }
}